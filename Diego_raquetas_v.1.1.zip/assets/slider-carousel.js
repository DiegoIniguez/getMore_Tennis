document.addEventListener("DOMContentLoaded", () => {
  // Slider (izquierda)
  const sliderContent = document.querySelector('.slider-content');
  const images = document.querySelectorAll('.slider-content img');
  const prevBtn = document.querySelector('.prev-btn');
  const nextBtn = document.querySelector('.next-btn');
  const dotsContainer = document.querySelector('.dots-container');

  let currentIndex = 0;

  function createDots() {
    dotsContainer.innerHTML = "";
    images.forEach((_, index) => {
      const dot = document.createElement('div');
      dot.classList.add('dot');
      if (index === currentIndex) dot.classList.add('active');
      dotsContainer.appendChild(dot);
      dot.addEventListener('click', () => showSlide(index));
    });
  }

  function updateDots() {
    const dots = document.querySelectorAll('.dot');
    dots.forEach((dot, index) => {
      dot.classList.toggle('active', index === currentIndex);
    });
  }

  function updateButtons() {
    prevBtn.classList.toggle('inactive', currentIndex === 0);
    nextBtn.classList.toggle('inactive', currentIndex === images.length - 1);
  }

  function updateSlider() {
    sliderContent.style.transform = `translateX(-${currentIndex * 100}%)`;
    updateDots();
    updateButtons();
  }

  function showSlide(newIndex) {
    currentIndex = Math.min(Math.max(newIndex, 0), images.length - 1);
    updateSlider();
  }

  prevBtn.addEventListener('click', () => showSlide(currentIndex - 1));
  nextBtn.addEventListener('click', () => showSlide(currentIndex + 1));

  createDots();
  updateSlider();

  // Carousel (derecha)
  const carousel = document.querySelector('.product-carousel');
  let isDragging = false;
  let startX, scrollLeft, ignoreNextClick = false;

  carousel.addEventListener('mousedown', (e) => {
    isDragging = false;
    startX = e.pageX - carousel.offsetLeft;
    scrollLeft = carousel.scrollLeft;

    const handleMouseMove = (e) => {
      isDragging = true;
      const x = e.pageX - carousel.offsetLeft;
      const walk = (x - startX) * 1;
      carousel.scrollLeft = scrollLeft - walk;
    };

    const handleMouseUp = () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      carousel.style.cursor = 'grab';

      if (isDragging) {
        ignoreNextClick = true;
        setTimeout(() => ignoreNextClick = false, 0);
      }
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    carousel.style.cursor = 'grabbing';
  });

  carousel.addEventListener('click', (e) => {
    if (ignoreNextClick) {
      e.preventDefault();
      ignoreNextClick = false;
    }
  });

  carousel.addEventListener('wheel', (e) => {
    if (e.deltaY !== 0) {
      e.preventDefault();
      carousel.scrollLeft += e.deltaY;
    }
  });
});
